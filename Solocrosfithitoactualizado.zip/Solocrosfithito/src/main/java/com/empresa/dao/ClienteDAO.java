package com.empresa.dao;
//capa de gestion de datos:CRUD

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.empresa.model.Cliente;

public class ClienteDAO {

	private String endpoint="jdbc:mysql://localhost:3308/test?useSSL=false";//cambie el puerto de localhost por el que usted tenga en mi caso es el 3308 
	private String user="root";
	private String pass="";
	
	
	
	public Connection conectar() {
		System.out.println("hola guapo");
		Connection connection =null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 connection = DriverManager.getConnection(endpoint, user, pass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return connection;
	}//cierra metodo conectar
	
	
	
	public void insertCliente(Cliente c)  {
  
        // try-with-resource statement will auto close the connection.
		 Connection connection = conectar();
		 PreparedStatement ps;
        try {
        	
        	
        	ps = connection.prepareStatement("INSERT INTO abonados VALUES (?,?,?,?,?);");
           ps.setString(1,c.getNombre());
           ps.setString(2,c.getPlan());
           ps.setInt(3,c.getHoras());
           ps.setString(4,c.getPeso());
           ps.setInt(5,c.getEventos());
           ps.executeUpdate();
           
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	public Cliente publicarCliente(String usuario) {

	    Connection connection = conectar();

	    PreparedStatement ps;

	    ResultSet rs;

	    Cliente cliente = null;



	    try {

	        ps = connection.prepareStatement("SELECT * FROM abonados WHERE nombre = ?;");

	        ps.setString(1, usuario);

	        rs = ps.executeQuery();



	        if (rs.next()) {
	        	
	        	   String nombre = rs.getString("nombre");
	        	   String plan = rs.getString("plan");


	            int horas = rs.getInt("horas");
	            
	            String peso = rs.getString("peso");

	            int eventos = rs.getInt("eventos");

	         
	        

	     



	            // Crear el objeto Cliente con los datos obtenidos

	            cliente = new Cliente(nombre, plan, horas, peso, eventos);

	        }



	        rs.close();

	        ps.close();

	        connection.close(); // Cerrar la conexión



	    } catch (SQLException e) {

	        e.printStackTrace();

	    }



	    return cliente;

	}
    	
    }//cierrra insertar
	
	
	//resto de metodos crud
//cierra dao
